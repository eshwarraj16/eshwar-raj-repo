package automationone;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Switchingwindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
driver.findElement(By.xpath("//a[normalize-space()='OrangeHRM, Inc']")).click();

Set<String> windowid= driver.getWindowHandles();
List<String> windows= new ArrayList<String>(windowid);

String one= windows.get(0);

String two= windows.get(1);

driver.switchTo().window(two); 

	}

}




Set<String> windowid= driver.getWindowHandles();
//approach 1 this is applicable for only 2 windows
List<String> windows = new ArrayList<String>(windowid);
String first = windows.get(0);
String second = windows.get(1);

driver.switchTo().window(second);
System.out.println(driver.getTitle());


driver.switchTo().window(first);
System.out.println(driver.getTitle());