package automationone;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import net.bytebuddy.asm.Advice.Return;

public class Dataprovider {
	WebDriver driver;
   @BeforeClass
   void m1() {
	   driver= new FirefoxDriver(); 
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20)); }
	@Test(dataProvider = "testing")
	void m2(String id,String pswd) {
		 driver.get(" https://www.facebook.com/?stype=lo&flo=1&deoia=1&jlou=AffNpMivZEfBpen7EsSjmBE2CZapB5OR0kUVDi47FyntwOe4Ao0Tu4TsSOv0P9PzGMzyOkYxKy2fc1YTyRzYwN7tFgVQVuWPtF6fp2z-iHS5Og&smuh=25696&lh=Ac8O0bKL-rjDvnK6afM");
		  driver.findElement(By.xpath("//input[@id='email']")).sendKeys(id);
		  driver.findElement(By.xpath(" //input[@id='pass']")).sendKeys(pswd);
		  driver.findElement(By.xpath("//button[@id='u_0_c_GC']")).click();}
	
	@AfterClass
	void m3() {
		driver.close();
	}
@DataProvider(name="testing")
Object[][] m4(){
Object[][] data={	{"abc","123"},
	{"123","abc"},
	{"eshwarraj@1609@gmail.com","Karthick@16"}};
	return data;
}v

}


