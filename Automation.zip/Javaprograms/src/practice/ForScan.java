package practice;
import java.util.Scanner;

public class ForScan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc1.nextInt();
		System.out.println("enter a number"+num);
		
		System.out.println("number is:");
 double numb=sc1.nextDouble();
 System.out.println("number is:");
		
	}

}
