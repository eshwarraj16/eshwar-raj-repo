package automationone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
 
public class ConditionMethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver= new FirefoxDriver();
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
	Thread.sleep(5000); 
	//to find the element is getting displayed or not by using isdisplayed method
	WebElement image=driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']"));
	System.out.println(image.isDisplayed());
//to check whether the check box is checked or not	
Boolean	enabled=driver.findElement(By.xpath("//input[@id='Newsletter']")).isEnabled();
System.out.println(enabled);
//to check whether the button is selected or not
Boolean	selected=driver.findElement(By.xpath("//input[@id='gender-male']")).  isSelected();
System.out.println(selected);
}

}
