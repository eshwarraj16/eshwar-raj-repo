  package practice;
interface name{
	String first="test one";
	String second="test two";
	void m1();
	 static void m2() {
		 System.out.println("testing one");
	 }
	 default void m3() {
		 System.out.println("testing two");
	 }	
}  
public class Interfacedemo implements name {
	public void m1() {
		System.out.println("testing three");
	}public static void main(String[] args) {
		/*Interfacedemo idobj=new Interfacedemo();
		idobj.m1();
		idobj.m3();
		name.m2();*/
		//scenario 2
		name n1= new Interfacedemo();
		n1.m1();
		n1.m3();
		name.m2();
		
		

	}

}
