package practice;

public class Sumofarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,2,424,42,24};
		int sum =0;
		for(int i=0;i<a.length;i++) {
			sum= sum+a[i];		}
System.out.println("sum="+sum);
	}

}
