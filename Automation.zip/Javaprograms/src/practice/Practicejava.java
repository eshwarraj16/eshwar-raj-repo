package practice;

import java.util.Iterator;

public class Practicejava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	
		/*int a [][] = { {10,20},{30,40},{50,60}};
		/*System.out.println(a.length);
		System.out.println(a[2].length);
		System.out.println(a[2][1]);*/
		
		/*for (int r = 0; r < a.length; r++) {
			for (int c = 0; c < a[r].length; c++) {
				System.out.print(a[r][c]+"  ");
				
			}
			System.out.println();*/
		/*for (int arr[] :a) {
			for(int x :arr) {
				System.out.println(x);
			
		}}
			
		}*/
				
			
{			
int b[]={10,20,30,10,10,20};
int value =10;
int count=0;
for (int i = 0; i < b.length; i++) {
	if (value==b.length) {
		System.out.println(value);
		count++;
		

}}}}}
