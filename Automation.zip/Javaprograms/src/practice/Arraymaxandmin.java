package practice;

public class Arraymaxandmin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int a[]= {1,30,50,24,35};
     
     int max = a[0];
     for(int i=1;i<a.length;i++) {
    	 if(a[i]>max) {
    		max=a[i]; 
    	 }} System.out.println("  "+max);
/*	int min =a[0];
	
	for(int i=1;i<a.length;i++) {
		if(a[i]<min) {
			min=a[i]; 
		} 
	}
	System.out.println("  "+min);*/
	}
	

}
