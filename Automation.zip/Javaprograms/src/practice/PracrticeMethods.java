 package practice;

public class PracrticeMethods {
	//no return no param
	void method1()
	{
		System.out.println("hi");
		
	}
	//no param  with return
String method2()
{
	return("hello");
}
//no return with param
/*void method3(String name){
	System.out.println("name is "+name);*/
	//with return and param
	String method4(String area)
	{
		return("chennai"+area);
	}
	int x;
	String s1="eshwar";
	char a='a';
	void data1()
	{
		System.out.println(x+"   "+s1+"   "+a);
	}
	
	void data(int y,String s2,char b)
	{
		x=y;
		s1=s2;
		a=b;
	}
}

