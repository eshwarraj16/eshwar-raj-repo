package practice;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
public class Firstdemo {

public class Locator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//To invoke FireFox browser		
		//System.setProperty("webriver.gecko.driver", "C:\\geckodriver-v0.33.0-win64 (1)");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.amazon.in/?&tag=googhydrabk1-21&ref=pd_sl_5szpgfto9i_e&adgrpid=155259813593&hvpone=&hvptwo=&hvadid=674893540034&hvpos=&hvnetw=g&hvrand=12143057325090730963&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=20469&hvtargid=kwd-64107830&hydadcr=14452_2316413&gad_source=1");
		driver.manage().window().maximize();
	    /* String s=driver.getTitle();
		if(s.equals(s)) {
			System.out.println("pass");
		}else {
			System.out.println("fail");
		}*/
		/*driver.findElement(By.name("field-keywords")).sendKeys("iphone"); 
		driver.findElement(By.id("nav-search-submit-button")).click();
		boolean test=driver.findElement(By.id("nav-search-submit-button")).isDisplayed();
		System.out.println(test);
		driver.findElement(By.linkText("Best Sellers")).click();*/
		
		List<WebElement> header=driver.findElements(By.className("nav-a "));
		System.out.println(header.size());
		

	}

}
