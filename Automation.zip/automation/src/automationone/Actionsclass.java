package automationone;

import java.time.Duration;

//import javax.swing.plaf.basic.BasicSliderUI.ActionScroller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Actionsclass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.navigate().to("https://demo.opencart.com/");
		Thread.sleep(20000);
		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		Thread.sleep(20000);
			WebElement act= driver.findElement(By.xpath("//a[normalize-space()='Desktops']"));
	WebElement act2=driver.findElement(By.xpath("//a[normalize-space()='Mac (1)']"));
	Actions act3= new Actions(driver);
	Thread.sleep(20000);
	
	act3.moveToElement(act).moveToElement(act2).click().perform();	
	
	
	}

}
