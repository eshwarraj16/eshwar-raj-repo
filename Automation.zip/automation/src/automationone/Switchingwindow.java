package automationone;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Switchingwindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub ////span[normalize-space()='Coupons']

		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(390));
		 driver.get("https://www.amazon.com/");
		driver.switchTo().newWindow(WindowType.TAB);
		 driver.get("https://www.flipkart.com/");
			driver.switchTo().newWindow(WindowType.TAB);
			driver.get("https://www.facebook.com/login/");
			
			Set<String> windowid=driver.getWindowHandles();
			for(String ids : windowid) {
				String titles=driver.switchTo().window(ids).getTitle();
				System.out.println(titles);
				if(titles.equals("Log in to Facebook")) {
					driver.close();
				}
			}
		 
//WebElement ele1=		driver.findElement(By.xpath("//span[normalize-space()='Coupons']"));
//Actions act1 = new Actions(driver);
//act1.keyDown(Keys.CONTROL).click(ele1).keyUp(Keys.CONTROL).perform();
		//Alert a= driver.switchTo().alert();
		//a.dismiss();
	/*	Set<String> ids=driver.getWindowHandles();
		for(String id : ids) {
		String title =	driver.switchTo().window(id).getTitle();
		System.out.println(title);
		//if(title.equals(act))
		}
*/		
		
	//	System.out.println(ids); https://www.flipkart.com/

	}

}
