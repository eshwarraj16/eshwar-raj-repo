package automationone;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class getmethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver= new FirefoxDriver();
		driver.get("https://www.amazon.in/?&tag=googhydrabk1-21&ref=pd_sl_5szpgfto9i_e&adgrpid=155259813593&hvpone=&hvptwo=&hvadid=674893540034&hvpos=&hvnetw=g&hvrand=12143057325090730963&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=20469&hvtargid=kwd-64107830&hydadcr=14452_2316413&gad_source=1");
	Thread.sleep(5000); 
		driver.findElement(By.xpath("//*[@href=\"/deals?ref_=nav_cs_gb\"]")).click();
	System.out.println(driver.getTitle());//gets the title of the page
	System.out.println(driver.getCurrentUrl());//gets the current url of the page
	//String windowid =driver.getWindowHandle();
	//System.out.println(windowid);
	
	Set<String> windowsid=driver.getWindowHandles();
	System.out.println(windowsid);
	}
 
}
