package practice;

public class PracticeConstructor {
	
	int x,y;
	PracticeConstructor()
	{
		x=100;
		y=200;
	} 
	void sum()
	{
		System.out.println(x+y);
	}
	PracticeConstructor(int a, int b){
		a=10;
		b=20;
	}
	void sum1() { 
		System.out.println(a+b);
		
	}
	
	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
	PracticeConstructor pc1=new PracticeConstructor();
pc1.sum();
System.out.println();

PracticeConstructor pc2= new PracticeConstructor(10, 20);
pc2.sum1();
		
	}
}

