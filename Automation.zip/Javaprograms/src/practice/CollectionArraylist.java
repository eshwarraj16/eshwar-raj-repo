package practice;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionArraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list=new ArrayList();
		
		list.add(100);
		list.add("string");
		list.add('a');
		System.out.println(list);
		
		System.out.println(list.size());
		
		System.out.println(list.get(1));
		list.set(0, 10); 
	System.out.println(list);
	
	list.add(1,"java" );
System.out.println(list);

/*for (int i = 0; i < list.size(); i++) {
	System.out.println(list.get(i));
	}*/
/*for (Object i : list) {
	System.out.println(i);
	}*/
/*Iterator it=list.iterator();

while(it.hasNext()) {
	System.out.println(it.next());
}*/






	
	
	
		
		

	}

}
