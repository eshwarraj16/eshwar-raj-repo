package practice;

import java.util.Scanner;

public class Series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);

		System.out.println("enter the number");
		int num=sc.nextInt();
		for(int i=0;i<=num;i++) {
			for(int j=0;j<i;j++) {
				System.out.println(i);
			}
		}

	}

}
