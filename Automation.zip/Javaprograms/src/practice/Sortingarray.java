package practice;
import java.util.Arrays;

public class Sortingarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {50,30,20,40,10};
System.out.println(Arrays.toString(a));
int n=a.length;
for(int i=0;i<n-1;i++) {
for(int j=0;j<n-1;j++) {
	if(a[j]>a[j+1]) {
		int temp=a[j];
		a[j]=a[j+1];
		a[j+1]=temp;
	}
} 

}
System.out.println(Arrays.toString(a));
Arrays.parallelSort(a);//for sorting
/*Arrays.sort(a);
System.out.println(Arrays.toString(a));

String s1[] = {"abc","cab","qwr","ops"};
Arrays.sort(s1);
System.out.println(Arrays.toString(s1));
 
int a1[]= {10,20,30,40,50};
for(int i =a1.length-1;i>=0;i--) {
	System.out.println(a[i]);
}*/

		
	}

}
