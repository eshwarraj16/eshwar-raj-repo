package automationone;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Pageobjtwo {
	WebDriver driver;
	
	@BeforeClass
	void launch() {
		driver= new FirefoxDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
			}
	@Test
	void open (){
		Pageobject po=new Pageobject(driver);
		po.username("eshwarraj1609@gmail.com");
		po.password("Karthick@16");
		po.button();;
		}
	

}
