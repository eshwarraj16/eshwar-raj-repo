package practice;

public class PracticeMethodMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PracrticeMethods m1= new PracrticeMethods();
		m1.method1();
		
		String s= m1.method2();
		System.out.println(s);
		
		//m1.method3("karthick");
		
		System.out.println(m1.method4("chennai"));
	
		PracrticeMethods m= new PracrticeMethods();
		m.data(100, "eshwar",'v' );
		m.data1();
		
	} 

}
