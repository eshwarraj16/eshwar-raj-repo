package practice;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the string");
		String str = sc.next();
		 String rev="";
		 String org=rev;
		 for (int i = str.length()-1; i >=0; i--) {
			 rev = rev + str.charAt(i);
		 }
		 System.out.println(rev);
		 if(org.equals(rev)) {
			 System.out.println("palindrome");
		 }else {
			 System.out.println(" not palindrome"); 
		 }
		
}}
