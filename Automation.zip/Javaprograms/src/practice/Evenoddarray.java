package practice;

public class Evenoddarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {10,27,30,45,60,67,90};
		int esum=0; int osum=0;
		for(int i =0; i<a.length;i++) {
			if(a[i]%2==0) {
				esum= esum+ a[i];
				
			}
			else {
				osum=osum+a[i];
				
			}
		}

	
	System.out.println(esum);
	System.out.println(osum);
}}
