package practice;

public class Duplicatewords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		String s= "welcome to java welcome to selenium";
		String[] ch=s.split("\\s+");
		int count=0;
		for(String s1 :ch) {
			if(s1.equals("welcome")) {
				count++;
			}
		}
System.out.println("count is:"+count);
	}

}
