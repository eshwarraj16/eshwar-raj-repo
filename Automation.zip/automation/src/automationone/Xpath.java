package automationone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Xpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	WebDriver driver=new FirefoxDriver();
		
		driver.get("https://www.amazon.in/?&tag=googhydrabk1-21&ref=pd_sl_5szpgfto9i_e&adgrpid=155259813593&hvpone=&hvptwo=&hvadid=674893540034&hvpos=&hvnetw=g&hvrand=12143057325090730963&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=20469&hvtargid=kwd-64107830&hydadcr=14452_2316413&gad_source=1");
 driver.findElement(By.xpath("//input[@placeholder='Search Amazon.in']")).sendKeys("iphone 15");	
		//with multiple att ributes//driver.findElement(By.xpath("//input[@placeholder='Search Amazon.in'] [@name='field-keywords']")).sendKeys("iphone 15");
		/*driver.findElement(By.xpath("//a[text()='Sell']")).click();//this is by using inner text 
		Boolean test=driver.findElement(By.xpath("//a[text()='Sell']")).isDisplayed();
		System.out.println(test);
		 
		String test1=driver.findElement(By.xpath("//a[text()='Sell']")).getText();
		System.out.println(test1);*/
		//by using and or operator// driver.findElement(By.xpath("//input[@placeholder=\'Search Amazon.in\'] and [@name='field-keywords']")).sendKeys("iphone 15");
	//.contains and starts with 
  		//driver.findElement(By.xpath("//*[contains(@type,'subm')]")).click();
		driver.findElement(By.xpath("//*[starts-with(@type,'subm')]")).click(); 
		
	
	

	}

}
