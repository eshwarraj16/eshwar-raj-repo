package practice;

import java.util.Scanner;

public class Sumofevenandodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		int num = sc.nextInt();
		int evencount=0;
		int oddcount=0;
		
		while(num> 0) {
			  int rem= num%10;
			  if(rem %2==0) {
				  evencount++;
			  }else if 
				  oddcount++;
			  }
			  num=num/10;
			
		}
		System.out.println("number of even"+evencount);
		System.out.println("number of odd"+oddcount);
		
		

	}

}
