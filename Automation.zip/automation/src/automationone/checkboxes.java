package automationone;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class checkboxes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
//1.this is for selecting one checkbox
//driver.findElement(By.xpath("//input[@id='sunday']")).click();
//2.this is for selecting all checkbox
List<WebElement> checkbox = driver.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
//for(int i=0;i<checkbox.size();i++) {
	//checkbox.get(i).click();

/*	for(WebElement check : checkbox) {
		check.click();
	}*/
//3.this is for selecting first 3 checkboxes and another for loop is for disselecting selected checkboxes
for(int i=0;i<3;i++) {
	checkbox.get(i).click();
}
for(int i=0;i<3;i++) {
	checkbox.get(i).click();
}

}}
