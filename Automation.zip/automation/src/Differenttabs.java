import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Differenttabs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.get("https://www.amazon.com/");
		//driver.findElement(By.xpath("//a[normalize-space()='OrangeHRM, Inc']")).click();
		
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get("https://www.amazon.com/gp/goldbox?ref_=nav_cs_gb");
		Set<String> winid= driver.getWindowHandles();
		for(String id: winid) {
			String one= driver.switchTo().window(id);
		}
	}

}
