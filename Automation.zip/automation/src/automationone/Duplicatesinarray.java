package automationone;

import java.util.Arrays;
import java.util.Scanner;

public class Duplicatesinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int a[]= {10,20,30,40,50,30,30,30};
		/*int num=30;
		int count=0;
		for(int i=0;i<a.length;i++) {
			if(a[i]==num) {
				count++;
			}
		}*/
	int a[]= {10,20,30,40,50};
	int max=a[0];
	for(int i=0;i<a.length;i++) {
		if(max<a[i]) {
			max=a[i];
		}
	}
	System.out.println(max);
	
//System.out.println(count);*/
		//sorting array
		System.out.println(Arrays.toString(a));
		/*Arrays.sort(a);
		System.out.println(Arrays.toString(a));*/
		//reversing elements in a array
		for(int i=a.length-1;i>=0;i--) {
		System.out.println(a[i]);	
		
		/*int a[]=new int[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++) {
			System.out.println("enter a value=");
			a[i]=sc.nextInt();
			
		}
		System.out.println(Arrays.toString(a));
		*/}

	}}


