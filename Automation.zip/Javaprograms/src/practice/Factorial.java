package practice;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num ;
		int fact=1;
		for(int i=1;i<=5;i++)
		{
		fact=fact* i;
	
		}
	System.out.println("num"+fact);}

}
