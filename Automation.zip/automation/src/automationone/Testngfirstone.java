package automationone;

import org.testng.annotations.Test;

public class Testngfirstone {
	@Test
	void openapp() {
		System.out.println("opened");
	}
	@Test
void login()
	{
	System.out.println("logged in");
}
	@Test(priority = 0, enabled = false)
void logout() {
	System.out.println("logged out");
}
}



