package Javaprograms;

public class Searchingelementsinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
