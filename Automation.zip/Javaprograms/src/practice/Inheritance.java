 package practice;

class a{
	int a=10;
	void m1(){
		System.out.println(a);
	}
}
class b extends a{
	int b=20;
	void m2() {
		System.out.println(b);
	}
}
class c extends b
{
	int c=30;
	void m3() {
		System.out.println(c);
	}
}

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//single inheritance
		b obj =new b();
		System.out.println(obj.a);
		System.out.println(obj.b);
		obj.m1();
		obj.m2();
		//multilevel
		 c obj1=new c();
		 obj1.m3();
		System.out.println(obj1.a);
		obj1.m2();
 
	}

}
