package practice;

import java.util.Scanner;

public class Palindromenum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a num:");
		int num = sc.nextInt();
		 int rev=0;
		 int org=num;
		 
		 while(num != 0) {
			 rev = rev * 10 + num%10;//when we use % it will give last digit
			 num = num/10; //eliminates last digit and gives other number for every iteration
			 }
		 if (org==rev) {
			 System.out.println("palindrome");
			
		} else {
			System.out.println("not palindrome");

		}
		
System.out.println("reversed numberis:"+rev);
	}

}
