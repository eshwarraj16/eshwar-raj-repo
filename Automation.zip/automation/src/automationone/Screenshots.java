package automationone;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Network.UserAgent;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Screenshots {
  c
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub //div[@id='CardInstanceS4UPpYuvCck7iQwqS9DRvQ']//div[@class='_fluid-quad-image-label-v2_style_fluidQuadImageLabelBody__3tld0']
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.navigate().to("https://www.amazon.in/?&tag=googhydrabk1-21&ref=pd_sl_5szpgfto9i_e&adgrpid=155259813593&hvpone=&hvptwo=&hvadid=674893540034&hvpos=&hvnetw=g&hvrand=8496602974566979081&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1007809&hvtargid=kwd-64107830&hydadcr=14452_2316413&gad_source=1");
	//to take full page screenshot	
	/*TakesScreenshot ts=(TakesScreenshot) driver;
	File sourcefile= ts.getScreenshotAs(OutputType.FILE);
File targetfile=new File(System.getProperty("user.dir")+"\\fullpage\\screenshot.png");
sourcefile.renameTo(targetfile);*/
//to take separate part of the screen
WebElement ele = driver.findElement(By.xpath("//div[@id='CardInstanceS4UPpYuvCck7iQwqS9DRvQ']//div[@class='_fluid-quad-image-label-v2_style_fluidQuadImageLabelBody__3tld0']"));
Thread.sleep(20000);
File source= ele.getScreenshotAs(OutputType.FILE);

File target = new File(System.getProperty("user.dir")+"\\fullpage\\ele.png");
source.renameTo(target);
	}

}
