package automationone;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Alerts {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		/*driver.findElement(By.xpath("//button[@onclick='jsAlert()']")).click();
		Thread.sleep(10000);
		 
		Alert al= driver.switchTo().alert();
		System.out.println(al.getText());
al.accept();*/
		/*driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
		Thread.sleep(10000); 
		
		Alert al=driver.switchTo().alert();
		al.dismiss();
		al.accept();*/
		driver.findElement(By.xpath("//button[@onclick='jsAlert()']")).click();
		Thread.sleep(10000); 
		Alert myalert= wait.until(ExpectedConditions.alertIsPresent());
		myalert.accept();
	
		
	}

}
