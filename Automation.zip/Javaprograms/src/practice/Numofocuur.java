package practice;

public class Numofocuur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hi am New to Chennai";
				int count =s.length();
				int totalcount=s.replace("a", "").length();
				int tc= count-totalcount;
				System.out.println("total count"+tc);
				

	}

}
