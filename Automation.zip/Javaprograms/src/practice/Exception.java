package practice;

import java.util.Scanner;

public class Exception {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub 
		/*Scanner sc= new Scanner(System.in);
		
		int a[]=new int[5];
		
		System.out.println("enter the number:");
		int pos=sc.nextInt();
		
		System.out.println("enter the value");
		int value=sc.nextInt();
		a[pos]=value;
		System.out.println(a[pos]);
	/*try {
		a[pos]=value;
	}
	catch(Exception e)
	{
		System.out.println("enter the value");
		System.out.println(e.getMessage());
	}*/
		
	int num=10;
	int value =num/0;
	try {
		
     }
	catch (ArithmeticException e) {
		System.out.println(value);	
	}
		}
	}


