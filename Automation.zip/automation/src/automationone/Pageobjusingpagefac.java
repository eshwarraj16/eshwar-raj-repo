package automationone;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pageobjusingpagefac {
	 WebDriver driver;
	 //constructor
	Pageobjusingpagefac(WebDriver driver){
		driver=this.driver;
		PageFactory.initElements(driver,this);}
//locators
	@FindBy(xpath = "//input[@id='email']") WebElement username;
	@FindBy(xpath = "//input[@id='pass']") WebElement password;
	@FindBy(xpath = "//button[@id='u_0_9_wW']") WebElement button;
	
	//actionmethods
	public void user(String name) {
		username.sendKeys(name);
	}
	public void pswd(String pass) {
		password.sendKeys(pass);
	}
	public void click() {
		button.click();
	}
		
	
	
}
 