package practice;

import java.util.Arrays;

public class Incdec {
	String s1() {
return("gfdhgcgh");
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a= 10;
		//a++;[I@36d64342

		//System.out.println(a);
		
		int a[]= {100,300,450,50,660,70,800,90};	
		Arrays.sort(a); 
System.out.println(Arrays.toString(a));
Arrays.sort(a);
}

	Incdec id= new Incdec();
	String s= id.s1();
	System.out.println(s);
	


}
