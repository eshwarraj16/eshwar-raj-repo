package automationone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Pageobject {
WebDriver driver;
//1.constructor
Pageobject(WebDriver driver){                        
	this.driver=driver;
}
	//2.locators
By username= By.xpath("//input[@id='email']");
By password= By.xpath("//input[@id='pass']");
By clickbutton= By.xpath("//button[@id='u_0_9_wW']");

//3.action methods
public void username(String user) {
	driver.findElement(username).sendKeys(user);}
public void password(String pass) {
	driver.findElement(password).sendKeys(pass);}
	public void button() {
		driver.findElement(clickbutton).click();
		
	}
}


