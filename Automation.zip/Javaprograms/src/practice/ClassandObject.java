package practice;

public class ClassandObject {
	
	
	int id;
	String name;
	String area;
	Character grade;
	
	void display()
	{
		System.out.println(id);
		System.out.println(name);
		System.out.println(area);
		System.out.println(grade);
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	ClassandObject	co1= new ClassandObject();
	co1.area="chennai";
	co1.grade='a';
	co1.id=100;
	co1.display();
	

	}

}
