package automationone;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Javascexecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	WebDriver driver= new FirefoxDriver();
		driver.get("https://www.facebook.com/?stype=lo&flo=1&deoia=1&jlou=AfdYr-cRfugf4hk7pMkeipU8Sd9yezDA5LX2hB_gzdpqlsQPEcqA5FEqLljNcT1Ce5hXThGCntAyuzy_3Wvp2Wq22P17CcIAdpeLJ-2sUQvbUA&smuh=25696&lh=Ac-0bnGq8Yqck4MR3d4");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(90));
		WebElement ele=driver.findElement(By.xpath("//input[@id='email']"));
		WebElement button= driver.findElement(By.xpath("//input[@id='pass']"));
		WebElement clic=driver.findElement(By.xpath("//button[@id='u_0_9_5N'])"));
	//passing the textinto input box, alternate of sendkeys	
JavascriptExecutor js= (JavascriptExecutor) driver;
//js.executeScript("arguments[0].setAttribute('value','eshwarraj1609@gmail.com')", ele);
//js.executeScript("arguments[0].setAttribute('value','Karthick@16')",button );
//js.executeScript("arguments[0].click()", clic);
js.executeScript("arguments[0].setAttribute('value','eshwarraj1609@gmail.com')", ele);
		/*//2.locators 
		By username= By.xpath("//input[@id='email']");
		By password= By.xpath("//input[@id='pass']");
		By clickbutton= By.xpath("//button[@id='u_0_9_wW']");*/
	}

}
