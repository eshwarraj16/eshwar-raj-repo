 package automationone;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdowns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://testautomationpractice.blogspot.com/");
		WebElement dropdown= driver.findElement(By.xpath("//*[@id='country']"));
	Select obj = new Select(dropdown);
		
	obj.selectByValue("canada");
		//value.selectByVisibleText("France");
	List<WebElement> options= obj.getOptions();
	System.out.println(options.size());
	
	for(int i=0;i<options.size();i++) {
	System.out.println(options.get(i).getText());
	}
	 
	}
	
		

	}


