package automationone;

import java.util.HashMap;
import java.util.Map;

public class Noofoccuranceofcharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "shcvsjjhgjhvhcfkach";
		Map<Character, Integer> hm=new HashMap<Character, Integer>();
	char ch[]=	s.toCharArray();
for(char s1 : ch) {
	if(hm.containsKey(ch)) {
		hm.put(s1, hm.get(ch) + 1);
	}else {
		hm.put(s1, 1);}
	
}
System.out.println(s+ ":"+ hm);
	}
}
