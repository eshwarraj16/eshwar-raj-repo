package practice;

public class casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		long value=num;//upcasting
		System.out.println(value);
		
		float f=1000987.87F;
		double d=(double)f;//downcasting
		System.out.println(d);
		
		long l=100000;
		int val=(int) l;
		
	}}
