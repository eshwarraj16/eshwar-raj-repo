package practice;

public class Forstringprograms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="java";
char a[]=s.toCharArray();
String rev="";
for(int i=a.length-1;i>=0;i--) {
	rev= rev+a[i];
}
/*for(int i=s.length()-1;i>=0;i--)
{
	rev= rev+s.charAt(i);

}*/



	System.out.println(rev);	
		
	}

}
