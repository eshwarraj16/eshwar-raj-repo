package practice;


public class Arrays {
public static void main(String[] args) {
		// TODO Auto-generated method stub
//searching an element in a array
		int a[]= {10,20,30,40};
		int num=30;
		boolean status = false;
		for (int i = 0; i < a.length; i++) {
			if (a[i]==num) {
				System.out.println("found"+a[i]);
				status=true;
				}}

		if (status==false) {
			System.out.println("not found");
		}}}	//finding number of repeatation in an array		
		
	/*int b[]={10,20,30,10,10,20};
	int num= 20;
	int count =0;
	for (int value = 0; value < b.length; value++) {
		if (b[value]==num) {
			count++;
			
		}
		
	}
	System.out.println(count);
	}}*/
  

//to print every values of arrays{
	//Scanner sc= new scanner(System.in);
	
	
