package practice;

import java.util.Scanner;

public class Primenumberornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num =2;
		int count = 0;
		int samenum=num;
		
		if(num%samenum==0 && num%1==0) {
			System.out.println("prime");
		}
		else{
			System.out.println("not prime");
		}
		}}
		
	


