package automationone;

public class Searchelementsarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {10,20,30,40,50};
int searchelement= 30;

Boolean status=false;
for(int i=0;i<a.length;i++) { 
	if(a[i]==searchelement ) {
		System.out.println("element found");
		status = true;
		break;
	}
}
if(status=false) {
	System.out.println("element not found");
}
	}

}
