package automationone;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import net.bytebuddy.build.Plugin.Factory.UsingReflection.Priority;

public class NewTest {
	WebDriver driver;
	@Test(priority = 1)
	void fblogin() {
		
		driver=new FirefoxDriver();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  
		  driver.get(" https://www.facebook.com/?stype=lo&flo=1&deoia=1&jlou=AffNpMivZEfBpen7EsSjmBE2CZapB5OR0kUVDi47FyntwOe4Ao0Tu4TsSOv0P9PzGMzyOkYxKy2fc1YTyRzYwN7tFgVQVuWPtF6fp2z-iHS5Og&smuh=25696&lh=Ac8O0bKL-rjDvnK6afM");
	  driver.findElement(By.xpath("//input[@id='email']")).sendKeys("eshwarraj@1609@gmail.com");
	  driver.findElement(By.xpath(" //input[@id='pass']")).sendKeys("Karthick@16");
	  driver.findElement(By.xpath("//button[@id='u_0_c_GC']")).click();
	}
	
	
	
	
}


