package practice;

public class Static {

	int a=10;
	static int b=20;
	
	void m1()
	{
		System.out.println("test m1"); 
	} 
	static void m2()
	{
		System.out.println("team m2");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Static s= new Static();
		s.m1();
		System.out.println(b);
		
		
		

	}

}
