import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Singlewindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.findElement(By.xpath("//a[normalize-space()='OrangeHRM, Inc']")).click();
/*String winid= driver.getWindowHandle();
System.out.println("win id is :"+winid);*/
		Set<String> winids= driver.getWindowHandles();
		for(String winid :winids ) {
			String ids= driver.switchTo().window(winid).getTitle();
			System.out.println(ids);
		}}}
