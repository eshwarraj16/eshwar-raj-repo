package automationone;

import java.util.Iterator;

import org.openqa.selenium.devtools.v131.domsnapshot.model.ArrayOfStrings;

public class Reversestring { 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		String s="hi am eshwar";
		String s1[]=s.split(" ");
		String reverse="";
		for(String s2:s1) {
			String words="";
			for(int i= s2.length()-1;i>=0;i--) {
				words=words+s2.charAt(i);
			}
			reverse=reverse+ words+" ";
		}
		System.out.println("fgdfgdfg"+reverse);
	    
	}
	

}
/*String str1="hi am eshwar";
String[] str2=str1.split(" ");
String reversestring="";

for (String str3: str2) {  
String words="";
for(int i=str3.length()-1;i>=0;i--) {
	 words= words+str3.charAt(i);
	}
reversestring=reversestring+words+"  ";
}
System.out.println(reversestring);*/