package practice;

public class Scanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
