package practice;

class bank{
	void m1() {
		System.out.println("test");
	}
}
class bank1 extends bank{
	void m1() {
		System.out.println("test1");
	}
}
class bank2 extends bank{
	void m1() {
		System.out.println("test2");
	}
}

public class Overriding {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		bank1 b1=new bank1(); 
		b1.m1();

	}

}
