package practice;

import java.util.Scanner;

public class Reversestring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the string:");
		Scanner sc = new Scanner(System.in);
		
		String s1=sc.next();
		String[] s2=s1.split(" ");
		String rev=""
;
		for(String s3: s2) {
			String words=" ";
			for(int i=s3.length()-1;i>=0;i++) {
				words=words+s3.charAt(i);
			}
			rev=rev+words+"      ";
		}
		//System.out.println(rev);
		//String s4="wel";
		//s4.concat("come");
		//System.out.println(s4);
		
		

	}

}
