package practice;

public class Duplicateinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arr[]= {"a1","a2","a7","a6"};
		 Boolean status=false;
		 for(int i=0;i<arr.length;i++) {
			 for(int j=i+1;j<arr.length;j++) {
				 if(arr[i]==arr[j]) {
			   System.out.println(" found");
			   status=true;
			 }}
		 }
		 if(status==false) { 
			 System.out.println("not found");
		 }

	}

}
